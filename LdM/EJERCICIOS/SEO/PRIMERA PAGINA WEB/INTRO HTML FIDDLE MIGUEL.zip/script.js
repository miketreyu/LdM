function hello() {
    alert("Good Day");
  }
  
  function showtime() {
    var now = new Date();
    alert(now);
  }
  